/*
*           Custom code javaScript
*           Место для твоего кода  
*/

$(function(){    
    /*
    *   событие клика на ссылку в боковой панели.
    *   плавно перемешаемся на нужный контент
    */
   $('.sidebar-menu a').on('click', function(event) {        
        var hash = event.currentTarget.hash;
        $(event.currentTarget).addClass('active');
        $('html, body').animate({
            scrollTop: $(hash).offset().top, 
        }, 1000);
        return false;
   });

   /*
   *    отслеживаем движения скролла и при
   *    появлении элемента в окне помечаем это классом в меню
   */
   //   стек из объектов в одной ячейке элемент контента и ссылка на этот 
   //   элемент
   var stack = [];
   $('.sidebar-menu a').each(function(){
       stack.push([
           $( $(this).attr('href') ), 
           $(this)
        ]);
    });
    var win_height = $(window).height();
   $(window).on('scroll', function(event) {
        var top_win = $(window).scrollTop();
        var bottom_win = top_win + win_height;
        
        //  перебераем стек объектов и проверяем 
        //  в видимой он области или нет
        stack.forEach(function(elem) {
            var top_elm = elem[0].offset().top;
            if ( top_elm > top_win && top_elm < bottom_win) {
               elem[1].addClass('active');
            } else {
                elem[1].removeClass('active');
            }
        })   
   });
   $(window).resize(function( ){
        win_height = $(window).height();
   });

});

